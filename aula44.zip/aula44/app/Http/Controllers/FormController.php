<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// Integrando ao Model Movie
use App\Movie;

// Integrando ao Model Genre
use App\Genre;

class FormController extends Controller
{
    //
}
